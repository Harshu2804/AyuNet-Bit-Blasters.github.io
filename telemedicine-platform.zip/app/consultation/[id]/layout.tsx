import type React from "react"

export default function ConsultationLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
